<?php

namespace Figure;


abstract class Figure
{
    abstract public function calculate_Square();

}