<?php

namespace Car;


interface Car_Oil
{
    public function change_Oil();

}