<?php
/**
 * Created by PhpStorm.
 * User: Dima
 * Date: 13.07.2020
 * Time: 14:29
 */

namespace Car;


interface Car_Complect
{
    public function count_Wheels();
    public function count_Doors();

}